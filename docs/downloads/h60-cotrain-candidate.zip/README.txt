Single-band float32 GeoTIFF, EPSG:32611, 3730x3292 at 100 m.
Every pixel is finite and in {0,1}; 37654 pixels are 1.
Submit the .tif (or this .zip) on the competition submission page.
